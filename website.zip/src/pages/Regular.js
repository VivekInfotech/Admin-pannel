import React from 'react'

function Regular() {
  return (
    <>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
        <h1>lllllk</h1>
    
    </>
  )
}

export default Regular