import React from 'react'

function Authors() {
  return (
   <> <div>Authors</div>
   <div>Authors</div>
   <div>Authors</div>
   <div>Authors</div>
   <div>Authors</div>
   <div>Authors</div>
   <div>Authors</div></>
  )
}

export default Authors